<?php
$db_config = array(
    'host'  => '127.0.0.1',
    'user'  => 'root',
    'pass'  => 'root',
    'db'    => 'adb');
?>