<?php
Header('Location:/wd/atm/g-bits/patch.zip');
?>