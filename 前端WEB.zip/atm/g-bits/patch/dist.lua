﻿return {
  ["default"] = {
        ver = "2.049r.0114",
        review_account = {"110001frmkv9u5"},
        dist = "权倾天下",
        ftpHost = "221.229.210.13",
        ftpPort = "21",
        ftpUser = "atm",
        ftpPwd = "WJD6KRUI9jZ",
        disable_increment_download = true,
        accList = {"110001runlmv6i","110001ies8gr3v","110001ikurjy1h","110001mu07vmpk","110001gs455hit","1100016z0mdyx1"},
        service_infos = {
              { ["key"] = "qq", ["value"] = {} },
              { ["key"] = "qq_group", ["value"] = {} },
              { ["key"] = "wx", ["value"] = {} },
              { ["key"] = "tel", ["value"] = {} },
        },
        new_package_first_version = "2.045r.1022",
        force_update_version = "2.046r.1105",
        update_package_time = "2019-11-07 04:59:59",
    },

  ["groups"] ={
       "权倾天下"},
	   ["权倾一区"] = { aaa = "221.229.210.13:8001", group = "权倾天下", state = 2, isNew = true },
	   ["权倾二区"] = { aaa = "45.248.8.246:8001", group = "等待开放", state = 2, isNew = true },
	   ["权倾三区"] = { aaa = "45.248.8.184:8001", group = "等待开放", state = 2, isNew = true },
}