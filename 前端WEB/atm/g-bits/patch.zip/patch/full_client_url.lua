return {
  ["g-bits"] = "http://wd.leiting.com/game/download_app.php",
}