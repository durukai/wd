﻿return {
  ["default"] = {
        ver = "2.071r.0602",
        review_account = {"110001frmkv9u5"},
        dist = "发财猫",
        ftpHost = "82.157.39.116",
        ftpPort = "21",
        ftpUser = "atm",
        ftpPwd = "WJD6KRUI9jZAQ",
        disable_increment_download = true,
        accList = {"110001runlmv6i","110001ies8gr3v","110001ikurjy1h","110001mu07vmpk","110001gs455hit","1100016z0mdyx1"},
        service_infos = {
              { ["key"] = "qq", ["value"] = {} },
              { ["key"] = "qq_group", ["value"] = {} },
              { ["key"] = "wx", ["value"] = {} },
              { ["key"] = "tel", ["value"] = {} },
        },
        new_package_first_version = "2.045r.1022",
        force_update_version = "2.046r.1105",
        update_package_time = "2019-11-07 04:59:59",
    },

  ["groups"] ={
       "一区"},
	   ["发财猫"] = { aaa = "82.157.39.116:8001", group = "一区", state = 2, isNew = true },  
   
}