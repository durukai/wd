return {
  "http://82.157.39.116:88/wd/g-bits",
}